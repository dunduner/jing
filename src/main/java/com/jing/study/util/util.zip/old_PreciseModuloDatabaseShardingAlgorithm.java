package com.jing.study.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.shardingsphere.api.sharding.standard.PreciseShardingAlgorithm;
import org.apache.shardingsphere.api.sharding.standard.PreciseShardingValue;

import java.util.Collection;

/**
 * @author zhangning
 * @date 2020/8/14
 */
//数据库分库规则
public class old_PreciseModuloDatabaseShardingAlgorithm implements PreciseShardingAlgorithm<String> {
    /**
     * @param collection 存放的是所有的库的列表，这里代表master20201,master20202
     *                   每五年一个裤 master20201(2020~2024),master20202(2025~2029)
     * @return 将数据写入的哪个库,String类型,库名字符串
     */
    @Override
    public String doSharding(Collection<String> collection, PreciseShardingValue<String> preciseShardingValue) {
        try {
            //配置的分库分片的sharding-column对应的值,也就是具体时间
            //025-05-15 14:39:18
            String str = preciseShardingValue.getValue();
            if (str.isEmpty()) {
                System.out.println("没拿到值");
                throw new UnsupportedOperationException("pre is null");//
            }
            //each为每个库的名字
            for (String each : collection) {
                String yearValue = StringUtils.substring(str, 0, 4);
                // 拿到年份
                //以5年为一个库,例如：2020~2024
                int c = Integer.parseInt(yearValue) - 2020;
                //算差值，拿当前时间减去2020，用差除于5，会得到小数，用int强转，只要整数，这样为0的就放到1库，为1的就放到2库
                int database_hou_zhui = c / 5;// 0 就是2020-2024年

                if (each.endsWith(Integer.toString(database_hou_zhui + 1))) {
                    //扔到后缀是database_hou_zhui+1的库,判断当前这个库是否符合我条件，
                    // 而不是我去找符合我条件的库，因为没法找，好多库呢
                    return each;
                }
            }
        } catch (Exception e) {
            System.out.println("分库逻辑异常!!!!");
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) {
        System.out.println(0 / 5);
        System.out.println(1 / 5);
        System.out.println(2 / 5);
        System.out.println(3 / 5);
        System.out.println(4 / 5);
        System.out.println("===");
        System.out.println(5 / 5);
        System.out.println(6 / 5);
        System.out.println(7 / 5);
        System.out.println(8 / 5);
        System.out.println(9 / 5);

    }
}
